declare const Hello: () => import("react/jsx-runtime").JSX.Element;
export default Hello;
